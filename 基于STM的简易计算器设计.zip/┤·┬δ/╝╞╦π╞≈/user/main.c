#include "stm32f10x.h"
#include "delay.h"
#include "LCD1602.h"
#include "keyscan.h"
#include "stdio.h"
#include "stdlib.h"
#include <string.h>
char str[10],str1[10],str2[11],z[2],Q[33];
u8  key,a=16,c=0,d=1,m,n,f,j,p,q,w;
u32 num,num1;
double num2;
//inf �����   nan  ������


void main_menu()    //LCD��ʾ
{	
	LCD_init();
	LCD_write_string(16,2,"0");
}

void zm_init()    //���б����ĳ�ʼ��
{
	m=0;      //�ַ���λͳ�Ʊ���
	n=0;      //�ڶ�λ�ַ���λͳ�Ʊ���
	f=0;       //��־λ���ж��Ƿ���Ҫ��һ��
	p=0;       //��������֮���жϽ����Ǹ�����
	d=1;       //�ж��Ƿ���Ҫ���еȺ�
	c=0;       //�ж��������������
	w=0;        //�ж��Ƿ���Ҫ����
	num=num1=0;
	for(j=0;j<10;j++)
	{
		str[j]=0;
	}
	for(j=0;j<10;j++)
	{
		str1[j]=0;
	}	
	for(j=0;j<11;j++)
	{
		str2[j]=0;
	}
	for(j=0;j<33;j++)
	{
		Q[j]=0;
	}
}

void Lcd_set()   //���ֻ�Ϊ�ַ��������飬������һ�����������ʾ��lcd�ĵڶ���
{
	sprintf(z,"%d",key);
	strcat(str,z);	
	strcat(Q,z);
	LCD_init();
	if(strlen(str)>9)
	{
		LCD_init();
		LCD_write_string(1,1,"Calculated value");     //�����ֵ������Χ
		LCD_write_string(1,2,"out of range!");	
		zm_init();
		delay_ms(500);
		delay_ms(500);
		main_menu();
	}
	else
	{
		LCD_write_string(a-m,2,(u8 *)Q);
		m++;
	}
}

void number_init()              //��һ����������
{
	if((key==0)&&(str[0]!='0'))
	{
		Lcd_set();
	}
	if((key==1)&&(str[0]!='0'))
	{
		Lcd_set();
	}
	if((key==2)&&(str[0]!='0'))
	{
		Lcd_set();
	}
	if((key==3)&&(str[0]!='0'))
	{
		Lcd_set();
	}
	if((key==4)&&(str[0]!='0'))
	{
		Lcd_set();
	}
	if((key==5)&&(str[0]!='0'))
	{
		Lcd_set();
	}
	if((key==6)&&(str[0]!='0'))
	{
		Lcd_set();
	}
	if((key==7)&&(str[0]!='0'))
	{
		Lcd_set();
	}
	if((key==8)&&(str[0]!='0'))
	{
		Lcd_set();
	}
	if((key==9)&&(str[0]!='0'))
	{
		Lcd_set();
	}
}

void Lcd1_set()      //�ַ��������飬��lcd��ʾ������λ������ʾ����һ����ڶ��н��ʹ�á�
{
	sprintf(z,"%d",key);
	strcat(str1,z);
	strcat(Q,z);
	LCD_init();
	if(f==0)
	{
		LCD_write_string(a-m,2,(u8 *)Q);
		m++;
	}
	else
	{				
		LCD_write_string(a-n,1,(u8 *)Q);
		LCD_write_string2(-n,2,(u8 *)Q+n+1);
		n++;
	}
	if(strlen(str1)>9)
	{
		LCD_init();
		LCD_write_string(1,1,"Calculated value");     //�����ֵ������Χ
		LCD_write_string(1,2,"out of range!");	
		zm_init();
		delay_ms(500);
		delay_ms(500);
		main_menu();
	}
}

void number1_init()       //�ڶ�����������
{
	if((key==0)&&(str1[0]!='0'))
	{
		Lcd1_set();
	}
	if((key==1)&&(str1[0]!='0'))
	{
		Lcd1_set();
	}
	if((key==2)&&(str1[0]!='0'))
	{
		Lcd1_set();
	}
	if((key==3)&&(str1[0]!='0'))
	{
		Lcd1_set();
	}
	if((key==4)&&(str1[0]!='0'))
	{
		Lcd1_set();
	}
	if((key==5)&&(str1[0]!='0'))
	{
		Lcd1_set();
	}
	if((key==6)&&(str1[0]!='0'))
	{
		Lcd1_set();
	}
	if((key==7)&&(str1[0]!='0'))
	{
		Lcd1_set();
	}
	if((key==8)&&(str1[0]!='0'))
	{
		Lcd1_set();
	}
	if((key==9)&&(str1[0]!='0'))
	{
		Lcd1_set();
	}
}


void dhcl()   //�ȺŴ���
{
	if(c==1)
	{
		sprintf(str2,"%0.2f",num2);
	}
	else
	{
		sprintf(str2,"%d",(u32)num2);
	}
	strcat(Q ,"=");	
	strcat(Q ,str2);
	LCD_init();
	if(strlen(Q)<=16)
	{
		LCD_write_string(a-m-strlen(str2),2,(u8 *)Q);
	}
	else
	{				
		LCD_write_string(a+17-strlen(Q),1,(u8 *)Q); 
		LCD_write_string2(a-strlen(Q),2,(u8 *)Q+strlen(Q)-16);			
	}
	if(strlen(Q)==24)
	{
		LCD_write_string(a+17-strlen(Q),1,(u8 *)Q); 
		LCD_write_string2(a-strlen(Q),2,(u8 *)Q+strlen(Q)-17);
	}
	if(strlen(Q)==25)
	{
		LCD_write_string(a+17-strlen(Q),1,(u8 *)Q); 
		LCD_write_string2(a-strlen(Q),2,(u8 *)Q+strlen(Q)-18);
	}	
	if(strlen(Q)==26)
	{
		LCD_write_string(a+17-strlen(Q),1,(u8 *)Q); 
		LCD_write_string2(a-strlen(Q),2,(u8 *)Q+strlen(Q)-19);
	}		
	if(strlen(Q)==27)
	{
		LCD_write_string(a+17-strlen(Q),1,(u8 *)Q); 
		LCD_write_string2(a-strlen(Q),2,(u8 *)Q+strlen(Q)-20);
	}
	if(strlen(Q)==28)
	{
		LCD_write_string(a+17-strlen(Q),1,(u8 *)Q); 
		LCD_write_string2(a-strlen(Q),2,(u8 *)Q+strlen(Q)-21);
	}		
	if(strlen(Q)==29)
	{
		LCD_write_string(a+17-strlen(Q),1,(u8 *)Q); 
		LCD_write_string2(a-strlen(Q),2,(u8 *)Q+strlen(Q)-22);
	}	
	if(strlen(Q)==30)
	{
		LCD_write_string(a+17-strlen(Q),1,(u8 *)Q); 
		LCD_write_string2(a-strlen(Q),2,(u8 *)Q+strlen(Q)-23);
	}	
}

void Ope_yiwei()     //������λ
{
	LCD_init();
	LCD_write_string(a-m,2,(u8 *)Q);
	m++;
}

void Operation_init()      //������������
{
	if(key==14)        // #һ������
	{
		zm_init();
		main_menu();
	}
	if(w>1)
	{
		if(c==1)
		{	
			zm_init();
			sprintf(str,"%0.2f",num2);
			num=atol(str);
			sprintf(Q,"%0.2f",num2);
			m=strlen(str);
		}
		else
		{	
			zm_init();
			sprintf(str,"%d",(u32)num2);
			num=atol(str);
			sprintf(Q,"%d",(u32)num2);
			m=strlen(str);
		}
	}
	if((key==10)&&(Q[strlen(Q)-1]!='+')&&(Q[strlen(Q)-1]!='-')&&(Q[strlen(Q)-1]!='*')&&(Q[strlen(Q)-1]!='/'))     //  +
	{
		p=1;
		q=1;
		d=1;
		w++;
		strcat(Q ,"+");
		Ope_yiwei();
	}
	if((key==11)&&(Q[strlen(Q)-1]!='+')&&(Q[strlen(Q)-1]!='-')&&(Q[strlen(Q)-1]!='*')&&(Q[strlen(Q)-1]!='/'))    //   -
	{
		p=1;
		q=2;
		d=1;
		w++;
		strcat(Q ,"-");
		Ope_yiwei();
	}
	if((key==12)&&(Q[strlen(Q)-1]!='+')&&(Q[strlen(Q)-1]!='-')&&(Q[strlen(Q)-1]!='*')&&(Q[strlen(Q)-1]!='/'))    //   %
	{
		p=1;
		q=3;
		d=1;
		c=1;
		w++;
		strcat(Q ,"/");
		Ope_yiwei();
	}
	if((key==15)&&(Q[strlen(Q)-1]!='+')&&(Q[strlen(Q)-1]!='-')&&(Q[strlen(Q)-1]!='*')&&(Q[strlen(Q)-1]!='/'))    //   *
	{
		p=1;
		q=4;
		d=1;
		w++;
		strcat(Q ,"*");
		Ope_yiwei();
	}
	if(key==13)      //   =
	{
//			num2=atol(str)+atol(str1);
		if((strlen(Q)!=0)&&(d==1))
		{	
			d=0;  
			if(q==1)
			{
				num2=num+num1;
				dhcl();
			}
			if(q==2)
			{
				num2=num-num1;
				dhcl();
			}
			if(q==3)
			{
				
				num2=(float)num/(float)num1;
				dhcl();
			}
			if(q==4)
			{
				if(strlen(str)+strlen(str1)>=10)
				{
					LCD_init();
					LCD_write_string(1,1,"Calculated value");     //�����ֵ������Χ
					LCD_write_string(1,2,"out of range!");	
					zm_init();
					delay_ms(500);
					delay_ms(500);
					main_menu();		
				}
				else
				{
					num2=num*num1;
				}
				dhcl();
			}
			if(q==0)
			{
				LCD_write_string(a-strlen(str),2,(u8 *)Q);			
			}
		}			
	}
}

int main()
{
	delay_init();
	main_menu();
	while(1)
	{	
		key=keyscan();
		Operation_init();
		if(p==0)
		{
			number_init();
			num=atol(str);
		}
		else
		{
			number1_init();
			num1=atol(str1);
		}
		if(m==16)f=1;
	}
}
