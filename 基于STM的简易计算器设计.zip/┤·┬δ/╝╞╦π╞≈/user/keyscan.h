#ifndef __KEYSCAN_H
#define __KEYSCAN_H 			   
#include "sys.h"

 
u8 keyscan(void);

#endif


