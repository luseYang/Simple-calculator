/************************************************************************************
							�������ṩ�����µ��̣�
								Ilovemcu.taobao.com
								epic-mcu.taobao.com
							ʵ�������Χ��չģ����������ϵ���
							���ߣ����زر���							
*************************************************************************************/
#include "LCD1602.h"


GPIO_InitTypeDef GPIO_InitStructure;
/* If processor works on high frequency delay has to be increased, it can be 
   increased by factor 2^N by this constant                                   */
#define DELAY_2N     0

//==================================================
void LCD_init(void)
{
    /*********************Һ��ʹ�õ�I/O�ڳ�ʼ��**************************/ 
	GPIO_InitTypeDef GPIO_InitStructure;
	
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_11 | GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    CLR_RW();			//��дλֱ�ӵ͵�ƽ��ֻд����

    /*********************Һ����ʼ��**************************/        
    delay (15000);
	

   
    CLR_RS();
    LCD_Write_half_byte(0x3);                 
    delay (15000);
    LCD_Write_half_byte(0x3);
    delay (15000);
    LCD_Write_half_byte(0x3);
    LCD_Write_half_byte(0x2);
   
    
    LCD_write_cmd(0x28);          // 4bit��ʾģʽ,2��,5x7����
    delay (20000);  
    LCD_write_cmd(0x08);         // ��ʾ�ر� 
    delay (20000); 
    LCD_write_cmd(0x01);         // ��ʾ���� 
    delay (20000); 
    LCD_write_cmd(0x06);         // ��ʾ����ƶ����� 
    delay (20000);
    LCD_write_cmd(0x0C);         //��ʾ��,���أ�
    //LCD_write_cmd(0x0F);         // ��ʾ������꿪�������˸
    delay (20000);
	LCD_write_cmd(0x01);         //����
}
/*--------------------------------------------------
����˵����д���Һ��


---------------------------------------------------*/
void LCD_write_cmd(unsigned char cmd)
{
    CLR_RS();
    LCD_Write_half_byte(cmd >> 4);
    LCD_Write_half_byte(cmd);
    delay (10000);
}
/*--------------------------------------------------
����˵����д���ݵ�Һ��


---------------------------------------------------*/
void LCD_write_data(unsigned char w_data)
{
    SET_RS();
    LCD_Write_half_byte(w_data >> 4);
    LCD_Write_half_byte(w_data);
    delay (10000);
}
/*--------------------------------------------------
����˵����д4bit��Һ��
--------------------------------------------------*/
void LCD_Write_half_byte(unsigned char half_byte)
{  
//    u16 temp_io = 0x0000;
//    temp_io = GPIO_ReadOutputData(GPIOE);   //���˿�E����ڵ�����
//    temp_io &= 0xfff0;                      //���ε���λ
//    temp_io |= (u16)(half_byte&0x0f);       //�õ�������
//    GPIO_Write(GPIOE,temp_io);              //д��������
	if (half_byte&0x01)
			GPIO_SetBits(GPIOB,GPIO_Pin_8);
	else
			GPIO_ResetBits(GPIOB,GPIO_Pin_8);

	if (half_byte&0x02)
			GPIO_SetBits(GPIOB,GPIO_Pin_5);
	else
			GPIO_ResetBits(GPIOB,GPIO_Pin_5);

	if (half_byte&0x04)
			GPIO_SetBits(GPIOB,GPIO_Pin_6);
	else
			GPIO_ResetBits(GPIOB,GPIO_Pin_6);

	if (half_byte&0x08)
			GPIO_SetBits(GPIOB,GPIO_Pin_7);
	else
			GPIO_ResetBits(GPIOB,GPIO_Pin_7);

    SET_EN();
    delay(2000);
    CLR_EN(); 
    delay(2000);
}

/*----------------------------------------------------
LCD_set_xy        : ����LCD��ʾ����ʼλ��
���������x��y    : ��ʾ�ַ�����λ�ã�X:1-16��Y:1-2                
-----------------------------------------------------*/
void LCD_set_xy( unsigned char x, unsigned char y )
{
    unsigned char address;
    if (y==1) 
    {
        address=0x80-1+x;
    }
    else 
    {
        address=0xc0-1+x;
    }
    LCD_write_cmd(address);
}

void LCD_set_xy2( unsigned char x, unsigned char y )
{
    unsigned char address;
    if (y==1) 
    {
        address=0x90-1+x;
    }
    else 
    {
        address=0xd0-1+x;
    }
    LCD_write_cmd(address);
}

/*---------------------------------------------------
LCD_write_string  : Ӣ���ַ�����ʾ����
���������*s      ��Ӣ���ַ���ָ�룻
          X��Y    : ��ʾ�ַ�����λ��                
---------------------------------------------------*/
void LCD_write_string(unsigned char X,unsigned char Y,unsigned char *s)
{
    LCD_set_xy( X, Y );   
    while (*s) 
    {
        LCD_write_data(*s);
        s++;
    }
}

void LCD_write_string2(unsigned char X,unsigned char Y,unsigned char *s)
{
    LCD_set_xy( X, Y );   
    while (*s) 
    {
        LCD_write_data(*s);
        s++;
    }
}

//=======================================================
/*
void Move(unsigned int step,unsigned int dirction,unsigned int time)
{
          unsigned int i;
         for(i=0;i<step-1;i++)
         {
              LCD_write_byte(1,dirction);      //�ַ��ƶ�����                                    
							Delay_nms(time);                //�����ƶ�ʱ��
         }
}
*/
//=========================================================
/*
void Flash_lcd(unsigned int delay_t, unsigned int times)
{
           unsigned int j;
         for(j=0;j<times;j++)
         {
                  LCD_write_byte(1,0x08);
                Delay_nms(delay_t);
                LCD_write_byte(1,0x0c);
                Delay_nms(delay_t);
         }
}
*/
//========================================================
void delay(vu32 cnt)
{
  cnt <<= DELAY_2N;

  while (cnt--);
}
//========================================================

