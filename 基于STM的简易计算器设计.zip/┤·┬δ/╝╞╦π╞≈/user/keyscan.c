#include "stm32f10x.h"
#include "delay.h"
u8 keynum(u8 k);
//4*4���̽ӿ�����PA0-PA7
u8 keyscan(void)
{    
	u16 cord_h,cord_l;  //;
	u8 Val = 0xFF;
	delay_init(); 
	
	GPIOA->CRL=0x33338888; 
	//GPIOA->CRH=0x44443333;	
	delay_us(1);
	//GPIOA->ODR = 0xFC3F;            //
	GPIOA->ODR = 0xFF0F;   
	delay_us(1);
	//cord_h = GPIOA->IDR & 0x003C;     //?????   //0000 0000 0011 1100
	cord_h = GPIOA->IDR & 0x000F; 
	if(cord_h != 0x000F)    //?????????     //1111 1100 0011 1111
	{
		delay_ms(100);        //??
		if(cord_h != 0x000F)  // 0000 0000 0000 0000 //1111 1100 0011 1111
		{                                              
			cord_h = GPIOA->IDR&0x000F;  //?????//
			GPIOA->CRL=0x88883333;  
			//GPIOA->CRH=0x44444488;  
			delay_us(1);
			GPIOA->ODR = cord_h|0xFFF0;  //???????1111 1111 1100 0011
			delay_ms(2);// ???????;
			cord_l = GPIOA->IDR&0x00F0;  //?????    0000 0011 1100 0000
			delay_us(1);
			//cord_h>>=2;
			//cord_l>>=2;
			Val = keynum((cord_h+cord_l)&0xff);
			return Val;                  //???????? 
		}
	}
	return 0xFF;     //????
}
/*---------------------------------------------------
������ӳ���
---------------------------------------------------*/
u8 keynum(u8 k)
{u8 a;
switch(k)
 {
  case 0x7e:a=10;break;  //a
	case 0x7d:a=11;break;   //b
  case 0x7b:a=12;break;    //c
  case 0x77:a=13;break;    //d
  case 0xbe:a=3;break;  //3
  case 0xbd:a=6;break;   //6 
  case 0xbb:a=9;break;   //9
  case 0xb7:a=14;break;   //#	 
  case 0xd7:a=0;break;   //0
  case 0xde:a=2;break;  //2
	case 0xdb:a=8;break;    //8
  case 0xdd:a=5;break;  //5  
  case 0xee:a=1;break;  //1
  case 0xed:a=4;break;  //4
  case 0xeb:a=7;break;   //7
  case 0xe7:a=15;break;  //*   
  default:a=0xff;break;
  
 }
 return(a);
}


